import React from 'react';
import { StoreProvider, useStore } from './context/StoreContext';
import { Layout } from './components/Layout';
import { Login } from './pages/Login';
import { MemberDashboard } from './pages/MemberDashboard';
import { StaffDashboard } from './pages/StaffDashboard';
import { RegisterMember } from './pages/RegisterMember';
import { MemberProfile } from './pages/MemberProfile';
import { RecordPayment } from './pages/RecordPayment';
import { Settings } from './pages/Settings';
import { UserRole } from './types';

const AppContent: React.FC = () => {
  const { currentUser, currentView } = useStore();

  if (!currentUser) {
    return <Login />;
  }

  return (
    <Layout>
      {/* Member Views */}
      {currentUser.role === UserRole.MEMBER && currentView === 'dashboard' && <MemberDashboard />}
      {currentUser.role === UserRole.MEMBER && currentView === 'member_profile' && <MemberProfile />}
      
      {/* Staff Views */}
      {currentUser.role === UserRole.STAFF && currentView === 'dashboard' && <StaffDashboard />}
      {currentUser.role === UserRole.STAFF && currentView === 'register_member' && <RegisterMember />}
      {currentUser.role === UserRole.STAFF && currentView === 'record_payment' && <RecordPayment />}
      {currentUser.role === UserRole.STAFF && currentView === 'settings' && <Settings />}
    </Layout>
  );
};

export default function App() {
  return (
    <StoreProvider>
      <AppContent />
    </StoreProvider>
  );
}